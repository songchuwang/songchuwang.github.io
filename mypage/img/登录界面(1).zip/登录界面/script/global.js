var user = new Array("songchuwang");
var pwd = new Array("songchuwang123");
var username = document.getElementById("username");
var userpwd = document.getElementById("userpwd");
var submit = document.getElementById("submit");
var sign_up = document.getElementById("sign-up");
var placeholder = document.getElementById("placeholder");
submit.onclick = function () {
    if (user.indexOf(username.value) != -1 && pwd.indexOf(userpwd.value) != -1) {
        placeholder.innerHTML = "登录成功!";
        return;
    }
    if (username.value == "" && userpwd.value == "") {
        placeholder.innerHTML = "请输入账号和密码!";
        return;
    }
    if (username.value != "" && userpwd.value == "") {
        placeholder.innerHTML = "请输入密码!";
        return;
    }
    if ((username.value != "" && userpwd.value != "") && !(user.indexOf(username.value) != -1) ||
        !(pwd.indexOf(userpwd.value)) != -1) {
        placeholder.innerHTML = "用户名或密码错误!";
        return;
    }
    if ((username.value != "") && !(user.indexOf(username.value) != -1) && (userpwd == "")) {
        placeholder.innerHTML = "账号不存在,请注册账号!";
        return;
    }

}
sign_up.onclick = function () {
    if (username.value == "") {
        placeholder.innerHTML = "请输入用户名!";
        return;

    }
    if ((user.indexOf(username.value) != -1)) {
        placeholder.innerHTML = "用户名已存在,请重新输入!";
        return;


    }
    if (!(user.indexOf(username.value) != -1) && (userpwd.value == "")) {
        placeholder.innerHTML = "请输入密码!";
        return;

    }
    if (!(user.indexOf(username.value) != -1) && (userpwd.value != "")) {
        user.push(username.value);
        pwd.push(userpwd.value);
        placeholder.innerHTML = "恭喜你注册成功!";
        return;

    }
}